// FireDataANT			Author: Ashley Theimer
// An object describing a single fire incident along with a Circle object that
// can be used to draw the incident within a map.

/*
javac --module-path %PATH_TO_FX% --add-modules javafx.controls FireDataANT.java
java --module-path %PATH_TO_FX% --add-modules javafx.controls FireDataANT
*/


import javafx.scene.shape.*;
import javafx.scene.paint.Color;

public class FireDataANT {
	private String callNum;	// number of individual times this fire was called in
	private int incidentType;	// integer ID for this type of fire
	private String description;	// description for this type of fire
	private String address;	// address where the fire took place
	private int alarms;	// number of alarms that were triggered from the fire
	private String alarmTime;	// the time the first fire alrarm went off
	private String primaryUnit;	// 
	private String neighborhood;	// neighborhood where the fire took place
	private double latitude;	// latitude where the fire took place
	private double longitude;	// longitude where the fire took place
	private Circle circle;	//
	private double coord;
	
	
	public FireDataANT(String cN, int i, String d, String add, int al, String aT,
						String pU, String n, double lat, double lng, 
						double smLat, double lgLat, double smLng, 
						double lgLng, int plotSize) {
		callNum = cN;
		incidentType = i;
		description = d;
		address = add;
		alarms = al;
		alarmTime = aT;
		primaryUnit = pU;
		neighborhood = n;
		latitude = lat;
		longitude = lng;
		double scaleFactor = Math.max(lgLat - smLat, lgLng - smLng);
		double xcoord = (Math.abs(longitude - smLng) * plotSize) / scaleFactor;
		double ycoord = plotSize - 
						((Math.abs(latitude - smLat) * plotSize) / scaleFactor);
		coord = ycoord;
		circle = new Circle(xcoord, ycoord, 3); // Circle(double centerX, double centerY, double radius)
		circle.setFill(Color.BLUE);
	}
	
	// returns the circle to the user
	public Circle getSpot() {
		return circle;
	}
	
	public double hah() {
		return coord;
	}
	
	// sets the circle radius to 3
	public void setVisible() {
		circle.setRadius(3);
	}
	
	// sets the circle radius to 0
	public void setInvisible() {
		circle.setRadius(0);
	}
	
	// returns the incidentType for the user
	public int getType() {
		return incidentType;
	}
	
	// returns the description for the user
	public String getDescription() {
		return description;
	}
	
	// returns true if the desc equals the objects description, false otherwise
	public boolean isType(String desc) {
		boolean result = false;
		if (description.equals(desc)) {
			result = true;
		}
		return result;
	}
	
	// returns true if the year equals the objects alarmTime year,
	// false otherwise
	public boolean isYear(int enteredYr) {
		boolean result = false;
		int year = Integer.parseInt(alarmTime.substring(alarmTime.length() - 4));
		if (year == enteredYr) {
			result = true;
		}
		return result;
	}
}