// FireMappingANT		Author: AMH + Ashley Theimer
// 
// A graphics application that visualizes the location of fires of various types
// within Pittsburgh and allows a variety of filtering for which fires are displayed.
//
// Data Source: https://data.wprdc.org/dataset/fire-incidents-in-city-of-pittsburgh

/*
set PATH_TO_FX="C:\Users\jimmy\Documents\CIS220\javafx-sdk-20.0.2\lib"
javac --module-path %PATH_TO_FX% --add-modules javafx.controls FireMappingANT.java
java --module-path %PATH_TO_FX% --add-modules javafx.controls FireMappingANT
*/



import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.shape.*;
import javafx.scene.paint.Color;
import javafx.scene.Group;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import java.util.Scanner;
import java.io.*;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import java.util.Arrays;
import javafx.scene.input.MouseEvent;

public class FireMappingANT extends Application {    

	// filename in current directory to use as data source
	// private final String filename = "pghFires_synthetic.txt";
	// private final String filename = "pghFires_small.txt";
	// private final String filename = "pghFires_medium.txt";
	private final String filename = "pghFires_cleansed.txt";
	
	private final int PLOTSIZE = 600;	// height and width of window

	private FireDataANT[] incidents;	// collection of all fire incident data points
	private TextField yearSelect;		// text field for selecting a year to display
	private Label details;				// label for displaying details of a fire

    public void start(Stage primaryStage) {
		
		int numFires = 0;
		double smLat = 180;
		double lgLat = 0;
		double smLng = 0;
		double lgLng = -180;
		
		try {
			Scanner filescan = new Scanner(new File(filename));		
			filescan.useDelimiter("\\t|\\r\\n");	// DO NOT CHANGE	
			
			/*
			TODO: process the data file to determine the number of rows of data as
			well as the smallest and largest longitudes and latitudes in the data set
			*/
			filescan.nextLine();			
			while(filescan.hasNext()) {
				numFires ++;
				
				// skip the unnessesary data
				for (int i = 0; i < 8; i ++) {
					filescan.next();
				}
				
				double lat = filescan.nextDouble();
				if (smLat > lat) {
					smLat = lat;
				} else {
					if (lgLat < lat) {
						lgLat = lat;
					}
				}
				
				double lng = filescan.nextDouble();
				if (smLng > lng) {
					smLng = lng;
				} else {
					if (lgLng < lng) {
						lgLng = lng;
					}
				}
			}
	
		} catch (IOException e) {System.out.println(e);};
		
		/*
		// recommended debugging statements
		 System.out.println("Number of incidents: " + numFires);
		 System.out.println("Min lat: " + smLat);
		 System.out.println("Max lat: " + lgLat);
		 System.out.println("Min long: " + smLng);
		 System.out.println("Max long: " + lgLng);
		 */
		
		/*
		TODO: instantiate "incidents"
		*/
		incidents = new FireDataANT[numFires];	
		
		/*
		TODO: reopen the data file in a new try-catch block with the same delimiter
		as above and scan it again, this time creating a FireDataXXX object for each row of data and storing it in the "incidents" array
		*/
		
		try {
			Scanner filescan = new Scanner(new File(filename));		
			filescan.useDelimiter("\\t|\\n");	// DO NOT CHANGE
			
			String callNum;
			int incidentType;
			String description;
			String address;
			int alarms;
			String alarmTime;
			String primaryUnit;
			String neighborhood;
			double latitude;
			double longitude;
			
			filescan.nextLine();
			for (int i = 0; i < incidents.length; i ++) {
				callNum = filescan.next();
				incidentType = filescan.nextInt();
				description = filescan.next();
				address = filescan.next();
				alarms = filescan.nextInt();
				alarmTime = filescan.next();
				primaryUnit = filescan.next();
				neighborhood = filescan.next();
				latitude = filescan.nextDouble();
				longitude = Double.parseDouble(filescan.next().trim());
				
				// gets rid of quotation marks in description and address
				if (description.substring(0, 1).equals("\"")) {
					description = description.substring(1,
						description.length() - 1);
				}
				if (address.substring(0, 1).equals("\"")) {
					address = address.substring(1, address.length() - 1);
				}
				
				incidents[i] = new FireDataANT(callNum, incidentType, 
					description, address, alarms, alarmTime, primaryUnit, 
					neighborhood, latitude, longitude, smLat, lgLat, smLng,
					lgLng, PLOTSIZE);
			}
			
		} catch (IOException e) {System.out.println(e);};
		
		
		FireIncident[] tempTypes = new FireIncident[100];
		int numTypes = 0;

		/*
		TODO: build a list of unique FireIncident objects stored in tempTypes where
		each one's count accurately reflects the number of times that incident
		occured in the data set
		numTypes must be incremented each time a new unique fire incident type is
		found so that when done numTypes is an accurate count of the number of
		unique fire incident types in this data set and also the index of the
		first null location in the dataset
		*/
		int incidentType;
		String description;
		for (int i = 0; i < incidents.length; i ++) {
			incidentType = incidents[i].getType();
			description = incidents[i].getDescription();
			boolean found = false;
			for (int j = 0; j < numTypes; j++) {
				found = false;
				if (tempTypes[j].getIncidentType() == incidentType) {
					tempTypes[j].increment();
					j = numTypes + 1;
					found = true;
				}
			}
			if (!found) {
				tempTypes[numTypes] = new FireIncident(incidentType,
					description);
				numTypes ++;
			}
		}

		// put tempTypes in sorted order, assuming tempTypes and numTypes have
		// been initialized accurately
		Arrays.sort(tempTypes, 0, numTypes, new FireIncident(0, ""));
		/*
		FireIncident[] fireTypes = new FireIncident[3];
		fireTypes[0] = new FireIncident(143, "Grass fire");
		fireTypes[1] = new FireIncident(111, "Building fire");
		fireTypes[2] = new FireIncident(100, "Fire, Other");
		*/
		/*
		TODO: copy the first ten items, or as many items as exist, into fireTypes
		to be the list of the most common fire incident types to include in the
		drop-down menu
		To do this, comment out the code line above that hard-codes incident
		descriptions into the fireTypes array and instead declare and instantiate
		the array with the following code and then initialize each item in the array
		*/
		FireIncident[] fireTypes = new FireIncident[Math.min(10,numTypes)];
		for (int i = 0; i < fireTypes.length; i++) {
			fireTypes[i] = tempTypes[i];
		}
		
		// button for showing only multi-alarm fires
		Button multiButton = new Button("Show Multi-alarm Fires");
		multiButton.setOnAction(this::multiAction);
		multiButton.setTranslateX(20);
		multiButton.setTranslateY(20);
		
		// text field for displaying only fires from a particular year
		Label yearLabel = new Label("Year: ");
		yearLabel.setTranslateX(180);
		yearLabel.setTranslateY(25);		
		yearSelect = new TextField();
		yearSelect.setPrefWidth(50);
		yearSelect.setTranslateX(210);
		yearSelect.setTranslateY(20);
		yearSelect.setOnAction(this::yearAction);
		
		// drop-down menu using fireTypes array for selecting fires that match
		// one of the most frequent fire incident types
		MenuButton choices = new MenuButton("Select Incident Type");
		choices.setTranslateX(290);
		choices.setTranslateY(20);
		for (int i=0; i<fireTypes.length; i++) {
			MenuItem newItem = new MenuItem(fireTypes[i].getDescription());
			choices.getItems().add(newItem);
			newItem.setOnAction(this::incidentAction);
		}
		
		// Label object for reporting the description of a particular fire
		details = new Label("");
		details.setTranslateX(50);
		details.setTranslateY(50);
		
		// button for setting map back to original configuration showing all
		// data items
		Button resetButton = new Button("Reset");
		resetButton.setOnAction(this::resetAction);
		resetButton.setTranslateX(460);
		resetButton.setTranslateY(20);

		// code for adding GUI elements and the Circle objects from the incidents
		// array to the display
		Group root = new Group(choices, multiButton, yearLabel, yearSelect,
								details, resetButton);
		// TODO: uncomment the following four lines of code once your FireDataXXX
		// object is defined to add a Circle for each item in the incidents array
		// to the root Group
		
		for (int i=0; i<incidents.length; i++) {
			Circle nextDot = incidents[i].getSpot();
			root.getChildren().add(nextDot);
		}
		
		
        Scene scene = new Scene(root, PLOTSIZE, PLOTSIZE, Color.WHITE);
		
		// the following line of code adds an event handler that responds
		// to mouse clicks to the graphics application
		scene.addEventHandler(MouseEvent.MOUSE_PRESSED, this::mousePressed);
		
        primaryStage.setTitle("Fire Incident Map");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

	// event handler for displaying only multi-alarm fires
	public void multiAction(ActionEvent event) {
		for (int i = 0; i < incidents.length; i ++) {
			incidents[i].setVisible();
			if (!(incidents[i].getNumAlarms() > 1)) {
				incidents[i].setInvisible();
			}
		}
		details.setText("");
		yearSelect.clear();
	}
	
	
	// Integer scanner idea for error checking:
	// https://stackoverflow.com/questions/12558206/how-can-i-check-if-a-value
	// -is-of-type-integer
	// I honestly though about using the scanner class before I found this 
	// solution, but this link helped me know how to implement it
	
	// event handler for displaying only alarms from the indicated year
	public void yearAction(ActionEvent event) {
		String text = ((TextField)(event.getSource())).getText();
		Scanner check = new Scanner(text);
		if(check.hasNextInt()) {
			int year = Integer.parseInt(text);
			for (int i = 0; i < incidents.length; i ++) {
				incidents[i].setVisible();
				if (!(incidents[i].isYear(year))) {
					incidents[i].setInvisible();
				}
			}
		} else {
			((TextField)(event.getSource())).clear();
		}
		details.setText("");
		yearSelect.clear();
	}

	// event handler for displaying only alarms with the selected incident type
	public void incidentAction(ActionEvent event) {
		String text = ((MenuItem)(event.getSource())).getText();
		for (int i = 0; i < incidents.length; i ++) {
			incidents[i].setVisible();
			if (!(incidents[i].isType(text))) {
				incidents[i].setInvisible();
			}
		}
		details.setText("");
		yearSelect.clear();
	}

	// event handler for displaying all fire incidents
	public void resetAction(ActionEvent event) {
		for (int i = 0; i < incidents.length; i ++) {
			incidents[i].setVisible();
		}
		details.setText("");
		yearSelect.clear();
	}

	// event handler for responding to mouse clicks
	private void mousePressed(MouseEvent event) {
		double pressX = event.getX();
		double pressY = event.getY();
		boolean found = false;
		for (int i = 0; i < incidents.length; i ++) {
			if (incidents[i].clicked(pressX, pressY)) {
				details.setText(incidents[i].toString());
				found = true;
				i = incidents.length;
			}
		}
		if (!found) {
			details.setText("");
		}
		yearSelect.clear();
	}
	
    public static void main(String[] args)
    {
        launch(args);
    }
}