// FireIncident		Author: AMH
// An object describing a single type of fire incident that has been found
// in the data set. Used to create a collection of all of the types of fires
// found in the data and then sort the collection to determine which fire
// types occur most frequently.

import java.util.Comparator;

public class FireIncident implements Comparator<FireIncident> {
	private int incidentType;		// integer ID for this type of fire
	private String description;		// description for this type of fire
	private int count;				// number of occurrences found for this type of fire
	
	// Constructor used to create object when first incident of this type of
	// fire is found
	public FireIncident(int i, String d) {
		incidentType = i;
		description = d;
		count = 1;
	}
	
	// update object to indicate another fire of this type has been found
	public void increment() {
		count++;
	}
	
	// get the integer ID of the fire type
	public int getIncidentType() {
		return incidentType;
	}
	
	// get the text description of this type of fire
	public String getDescription() {
		return description;
	}
	
	// return the total number of fires of this type found
	public int getCount() {
		return count;
	}
	
	// print summary for the object
	public String toString() {
		return incidentType + " " + count + " " + description;
	}
	
	// comparator used for determining which of two fire incident descriptors
	// comes first in sorted order based on the frequency stored in "count"
	@SuppressWarnings(("unchecked"))
	public int compare(FireIncident first, FireIncident second) throws ClassCastException {
		int result;
		if (first.getCount()<second.getCount()) {
			return 1;
		} else {
			if (first.getCount()==second.getCount()) {
				return 0;
			} else {
				return -1;
			}
		}
	}

}