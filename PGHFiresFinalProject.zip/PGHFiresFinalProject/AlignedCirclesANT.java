// AlignedCirclesANT.java	Author: AMH

/*
set PATH_TO_FX="C:\Users\jimmy\Documents\CIS220\javafx-sdk-20.0.2\lib"
javac --module-path %PATH_TO_FX% --add-modules javafx.controls AlignedCirclesANT.java
java --module-path %PATH_TO_FX% --add-modules javafx.controls AlignedCirclesANT
*/

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.shape.*;
import javafx.scene.paint.Color;
import javafx.scene.Group;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.Label;

import java.util.Scanner;

public class AlignedCirclesANT extends Application {

	// text fields for reading in number of circles and diameter of circles
	private TextField numberField, diameterField;
	// labels for indicating purpose of two text fields
	private Label numberLabel, diameterLabel;
	// button to request circles being drawn
	private Button drawButton;
	// Group object to be added to Scene, created as instance data so Circle
	// objects may be added or removed from it within the event handler
	private Group root;

	private final int WIN_WIDTH = 500; // width of graphics window in pixels
	private final int WIN_HEIGHT = 300; // height of graphics window in pixels

	public void start(Stage primaryStage) {
		numberField = new TextField();
		numberField.setPrefColumnCount(5);
		numberField.setTranslateX(110);
		numberField.setOnAction(this::drawAction);
		numberLabel = new Label("Number of circles:");
		numberLabel.setTranslateX(10);
		diameterField = new TextField();
		diameterField.setPrefColumnCount(5);
		diameterField.setTranslateX(310);
		diameterField.setOnAction(this::drawAction);
		diameterLabel = new Label("Diameter of circles:");
		diameterLabel.setTranslateX(200);
		drawButton = new Button("Draw");
		drawButton.setTranslateX(400);
		drawButton.setOnAction(this::drawAction);
		root = new Group(numberField, numberLabel, diameterField, diameterLabel, drawButton);
		Scene scene = new Scene(root, WIN_WIDTH, WIN_HEIGHT, Color.LIGHTGREEN);

		primaryStage.setTitle("Aligned Circles");
		primaryStage.setScene(scene);
		primaryStage.show();
	}

	public void drawAction(ActionEvent event) {
		// this line of code reset the Group "root" to only have the GUI
		// elements in it with any Circle objects that may have been included
		// in it previously removed from the Group
		root.getChildren().setAll(numberField, numberLabel, diameterField,
		diameterLabel, drawButton);
		// recall that, given a Circle object named "newCircle", the following
		// line of code will add that Circle object to the Group root:
		int numCircles = 0;
		int diameter = 0;
		
		String tempNumCircles = numberField.getText();
		String tempDiameter = diameterField.getText();
		//Double.parseDouble
		Scanner checkNumC = new Scanner(tempNumCircles);
		Scanner checkD = new Scanner(tempDiameter);
		
		if(checkNumC.hasNextInt()) {
			numCircles = Integer.parseInt(tempNumCircles);
		}
		if(checkD.hasNextInt()) {
			diameter = Integer.parseInt(tempDiameter);
		}
		if (numCircles > 0 && diameter > 0) {
			double separation = (double)WIN_WIDTH / (numCircles + 1);
			double yCoord = (double)WIN_HEIGHT / 2;
			double spaceLeft = WIN_WIDTH - (separation * numCircles);
			double diameterLength = diameter * numCircles;
			if (spaceLeft > 0 && diameterLength <= WIN_WIDTH){
				for (int i = 1; i <= numCircles; i++) {
					double xCoord = separation * i;
					Circle newCircle = new Circle(xCoord, yCoord, (diameter/2));
					root.getChildren().add(newCircle);
				}
			}
		}
		
		
		
		
		// root.getChildren().add(newCircle);
	}
	public static void main(String[] args) {
		launch(args);
	}
}