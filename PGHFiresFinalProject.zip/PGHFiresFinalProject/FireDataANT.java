// FireDataANT			Author: Ashley Theimer
// An object describing a single fire incident along with a Circle object that
// can be used to draw the incident within a map.

/*
javac --module-path %PATH_TO_FX% --add-modules javafx.controls FireDataANT.java
java --module-path %PATH_TO_FX% --add-modules javafx.controls FireDataANT
*/


import javafx.scene.shape.*;
import javafx.scene.paint.Color;

public class FireDataANT {
	private String callNum;	// a unique identifier for this specific fire
	private int incidentType;	// integer ID for this type of fire 
	private String description;	// description for this type of fire
	private String address;	// address where the fire took place
	private int alarms;	// number of alarms that were triggered from the fire
	private String alarmTime;	// the time the first fire alrarm went off
	private String primaryUnit;	// the unit that responded to the fire
	private String neighborhood;	// neighborhood where the fire took place
	private double latitude;	// latitude where the fire took place
	private double longitude;	// longitude where the fire took place
	private Circle circle;	// a visual element that displays the fire
	
	
	public FireDataANT(String cN, int i, String d, String add, int al, String aT,
						String pU, String n, double lat, double lng, 
						double smLat, double lgLat, double smLng, 
						double lgLng, int plotSize) {
		callNum = cN;
		incidentType = i;
		description = d;
		address = add;
		alarms = al;
		alarmTime = aT;
		primaryUnit = pU;
		neighborhood = n;
		latitude = lat;
		longitude = lng;
		double scaleFactor = Math.max(lgLat - smLat, lgLng - smLng);
		double xcoord = (Math.abs(longitude - smLng) * plotSize) / scaleFactor;
		double ycoord = plotSize - 
						((Math.abs(latitude - smLat) * plotSize) / scaleFactor);
		circle = new Circle(xcoord, ycoord, 3); 
		circle.setFill(Color.BLUE);
	}
	
	// returns the circle to the user
	public Circle getSpot() {
		return circle;
	}
	
	// sets the circle radius to 3
	public void setVisible() {
		circle.setRadius(3);
	}
	
	// sets the circle radius to 0
	public void setInvisible() {
		circle.setRadius(0);
	}
	
	// returns the incidentType for the user
	public int getType() {
		return incidentType;
	}
	
	// returns the description for the user
	public String getDescription() {
		return description;
	}
	
	// returns true if the desc equals the objects description, false otherwise
	public boolean isType(String desc) {
		boolean result = false;
		if (description.equals(desc)) {
			result = true;
		}
		return result;
	}
	
	// returns true if the year equals the objects alarmTime year,
	// false otherwise
	public boolean isYear(int enteredYr) {
		boolean result = false;
		int year = Integer.parseInt(alarmTime.substring(0, 4));
		if (year == enteredYr) {
			result = true;
		}
		return result;
	}
	
	// returns the number of alarms for this fire incident
	public int getNumAlarms() {
		return alarms;
	}
	
	// returns true if the click occurred within the circle, false otherwise
	public boolean clicked(double x, double y) {
		double xcoord = circle.getCenterX();
		double ycoord = circle.getCenterY();
		boolean result = false;
		if (circle.getRadius() == 3) {
			if ((x > (xcoord - 3)) && (x < (xcoord + 3))) {
				if ((y > (ycoord - 3)) && (y < (ycoord + 3))) {
					result = true;
				}
			}
		}
		return result;
	}
	
	public String toString() {
		String result = alarms + " alarms for " + description + " in " +
			neighborhood + " at " + alarmTime;
		return result;
	}
				
}