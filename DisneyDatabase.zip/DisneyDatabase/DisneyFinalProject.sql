-- \i /Users/jimmy/Downloads/TestFileForDisney.sql

DROP SCHEMA IF EXISTS "DISNEY" CASCADE;
CREATE SCHEMA "DISNEY";
SET search_path TO "DISNEY";

CREATE TYPE "parks" AS ENUM('Magic Kingdom', 'Disneyland', 'Hollywood Studios', 'Epcot', 'Animal Kingdom');
CREATE TABLE "PARKS"(
       "Name"					"parks"		PRIMARY KEY,
	   "OpenTime"				TIME(0)		NOT NULL,
	   "CloseTime"				TIME(0)		NOT NULL,
       "StreetNum"				INTEGER		NOT NULL,
       "StreetName"				TEXT		NOT NULL,
       "City"					TEXT		NOT NULL,
       "State"					TEXT		NOT NULL,
       "Zipcode"				INTEGER		NOT NULL,
	   "NumVisitors"			INTEGER		NOT NULL,
       "TicketPrice"			MONEY		NOT NULL
);

CREATE TABLE "PLACES"(
       "Name"			TEXT		PRIMARY KEY,
       "Park"			"parks"		NOT NULL,
       "Theme"			TEXT		NOT NULL,
	   FOREIGN KEY ("Park") REFERENCES "PARKS"("Name")
);

CREATE TABLE "SNACKS"(
       "Place"			TEXT		NOT NULL,
	   "Food"			TEXT		NOT NULL,
       "Calories"		INTEGER		NOT NULL,
       "Cost"			MONEY		NOT NULL,
	   PRIMARY KEY ("Place", "Food"),
	   FOREIGN KEY ("Place") REFERENCES "PLACES"("Name")
);

CREATE TYPE "Ride_Types" AS ENUM('Roller Coaster', 'Water', 'Boat', 'Omnimover', 'Show', 'Thrill');
CREATE TABLE "RIDES"(
       "Name"			TEXT			PRIMARY KEY,
       "Type"			"Ride_Types"	NOT NULL,
       "HourlyCapacity"	INTEGER			NOT NULL,
	   "OpenYear"		INTEGER			NOT NULL,
	   "Duration"		INTEGER			NOT NULL,
	   FOREIGN KEY ("Name") REFERENCES "PLACES"("Name")
	   
);

CREATE TYPE "visitor_type" AS ENUM('First Timer', 'Season Pass Holder', '>3 Hr Drive', '<5 Hr Drive', 'Out of Country');
CREATE TABLE "VISITORS"(
       "Fn"				TEXT			NOT NULL,
       "Ln"				TEXT			NOT NULL,
       "Hotel"			TEXT,
       "FavPlace"		TEXT			NOT NULL,
	   "VisitorType" 	"visitor_type"	NOT NULL,
	   PRIMARY KEY ("Fn", "Ln"),
       FOREIGN KEY ("FavPlace") REFERENCES "PLACES"("Name")
);

CREATE TABLE "TRANSACTIONS" (
	"Fn"		TEXT		NOT NULL,
    "Ln"		TEXT		NOT NULL,
	"Place"		TEXT		NOT NULL,
	"Item"		TEXT		NOT NULL,
	"Time"		TIMESTAMP	DEFAULT CURRENT_TIMESTAMP(2),
	"Total"		MONEY		NOT NULL,
	PRIMARY KEY ("Fn", "Ln", "Place", "Item"),
	FOREIGN KEY ("Fn", "Ln") REFERENCES "VISITORS"("Fn", "Ln"),
	FOREIGN KEY ("Place") REFERENCES "PLACES"("Name")
	);

CREATE TABLE "POSITIONS"(
       "PosName"	TEXT		PRIMARY KEY,
       "Costume"	BOOLEAN		NOT NULL,
	   "Hours"		INTEGER		NOT NULL,
       "Salary"		MONEY		NOT NULL
);

CREATE TABLE "EMPLOYEES"(
       "Fn"			TEXT		NOT NULL,
       "Ln"			TEXT		NOT NULL,
	   "Place"		TEXT		NOT NULL,
       "PosName"	TEXT		NOT NULL,
       "Email"		TEXT,
	   "PhoneNum"	VARCHAR(22),
	   PRIMARY KEY ("Fn", "Ln", "Place"),
	   FOREIGN KEY ("PosName") REFERENCES "POSITIONS"("PosName"),
	   FOREIGN KEY ("Place") REFERENCES "PLACES"("Name")
);

CREATE TABLE "TRANSPORTATION"(
       "Type"			TEXT		PRIMARY KEY,
	   "MK"				BOOLEAN		NOT NULL,
	   "DL"				BOOLEAN		NOT NULL,
	   "HS"				BOOLEAN		NOT NULL,
	   "Epcot"			BOOLEAN		NOT NULL,
	   "AK"				BOOLEAN		NOT NULL,
       "HourlyCapacity"	INTEGER		NOT NULL,
       "NumHotels"		INTEGER		NOT NULL,
       FOREIGN KEY ("Type") REFERENCES "PLACES"("Name")
);

INSERT INTO "PARKS" VALUES
	('Magic Kingdom', '09:00AM', '10:10PM', 1180, 'Seven Seas Drive', 'Lake Buena Vista', 'FL', 32830, 0, 189),
	('Epcot', '09:00AM', '10:10PM', 200, 'Epcot Center Dr', 'Lake Buena Vista', 'FL', 32830, 0, 189),
	('Hollywood Studios', '09:00AM', '10:10PM', 351, 'S Studio Dr', 'Lake Buena Vista', 'FL', 32830, 0, 149),
	('Disneyland', '09:00AM', '10:10PM', 1313, 'Disneyland Dr', 'Anaheim', 'CA', 92802, 0, 134),
	('Animal Kingdom', '09:00AM', '10:10PM', 2901, 'Osceola Pkwy', 'Lake Buena Vista', 'FL', 32830, 0, 159);

INSERT INTO "PLACES" VALUES
	('Haunted Mansion', 'Magic Kingdom', 'Haunted House'),
	('Space Mountain', 'Magic Kingdom', 'Outer Space'),
	('Peter Pans Flight', 'Magic Kingdom', 'Peter Pan'),
	('Tower of Terror', 'Hollywood Studios', 'Haunted Hotel'),
	('Rockin Roller Coaster', 'Hollywood Studios', 'VIP Tour of Aerosmith'),
	('Sorin', 'Epcot', 'Airport'),
	('Pirates of the Caribbean', 'Disneyland', 'Pirates'),
	('Living With the Land', 'Epcot', 'Greenhouse'),
	('Flight of Passage', 'Animal Kingdom', 'Pandora Tour'),
	('Monorail', 'Epcot', 'Transport'),
	('Skyliner', 'Epcot', 'Transport'),
	('Bus', 'Epcot', 'Transport'),
	('Taxi', 'Epcot', 'Transport'),
	('Boat', 'Epcot', 'Transport'),
	('Mickey Emporium', 'Magic Kingdom', '1930s U.S.A.'),
	('Epcot Shop', 'Epcot', 'Futuristic'),
	('Disneyland Shop', 'Disneyland', '1930s U.S.A.'),
	('Tomorrowland', 'Magic Kingdom', 'Futuristic'),
	('Frontieerland', 'Magic Kingdom', 'Wild West'),
	('Adventureland', 'Magic Kingdom', 'Jungle'),
	('Liberty Square', 'Magic Kingdom', 'Colonial America'),
	('Front of Park', 'Magic Kingdom', '1930s U.S.A.'),
	('Sunshine Tree Terrace', 'Magic Kingdom', 'Orange Bird'),
	('Cheshire Cafe', 'Magic Kingdom', 'Cheshire Cat'),
	('Donut Box', 'Epcot', 'Futuristic'),
	('Cosmic Rays', 'Magic Kingdom', 'Space Eatery'),
	('Pandora Store', 'Animal Kingdom', 'Pandora Store');


-- 'Roller Coaster', 'Water', 'Boat', 'Omnimover', 'Show', 'Thrill'
INSERT INTO "RIDES" VALUES
	('Haunted Mansion', 'Omnimover', 2000, 1971, 9),
	('Space Mountain', 'Roller Coaster', 1500, 1975, 3),
	('Tower of Terror', 'Thrill', 1260, 1994, 4),
	('Rockin Roller Coaster', 'Roller Coaster', 3000, 2000, 3),
	('Sorin', 'Show', 2088, 2005, 5),
	('Pirates of the Caribbean', 'Boat', 3000, 1967, 7),
	('Peter Pans Flight', 'Omnimover', 1000, 1967, 5),
	('Living With the Land', 'Boat', 1600, 1982, 15),
	('Flight of Passage', 'Show', 1500, 2017, 5);

INSERT INTO "POSITIONS" VALUES
	('Monorail Driver', FALSE, 6, 6000),
	('Skyliner Operator', FALSE, 6, 6000),
	('Bus Driver', FALSE, 14, 6000),
	('Boat Driver', FALSE, 6, 6000),
	('BoardingOperator', TRUE, 6, 8000),
	('Cashieer', TRUE, 3, 2000),
	('Seat Assigner', TRUE, 12, 4000),
	('Ride Manager', TRUE, 12, 1000),
	('TicketMaster', TRUE, 12, 5000);	

INSERT INTO "TRANSPORTATION" VALUES
	('Monorail', TRUE, TRUE, FALSE, TRUE, FALSE, 7000, 3),
	('Skyliner', FALSE, FALSE, TRUE, TRUE, FALSE, 4500, 4),
	('Bus', TRUE, TRUE, TRUE, TRUE, TRUE, 70, 25),
	('Boat', TRUE, FALSE, TRUE, TRUE, FALSE, 1800, 9);
	
INSERT INTO "EMPLOYEES" VALUES
	('Jane', 'Doe', 'Haunted Mansion', 'BoardingOperator', 'jane@gmail.com', 4435188100),
	('Joe', 'Cola', 'Cosmic Rays', 'Cashieer', 'joe@gmail.com', 4435188200),
	('Carol', 'Jones', 'Cosmic Rays', 'Cashieer', 'carol@gmail.com', 4435188204),
	('Joan', 'Carol', 'Haunted Mansion', 'Ride Manager', 'joan@gmail.com', 4437888200),
	('Paul', 'Carter', 'Pirates of the Caribbean', 'BoardingOperator', 'paul@gmail.com', 4437888256),
	('Joan', 'Ark', 'Boat', 'Boat Driver', 'joana@gmail.com', 4435188241),
	('Ashley', 'Theimer', 'Front of Park', 'TicketMaster', 'ashley@gmail.com', 4435188199);

INSERT INTO "SNACKS" VALUES
	--('Sunshine', 'Dole', 400, ),
	('Sunshine Tree Terrace', 'Dole Whip', 400, 6.75),
	('Cheshire Cafe', 'Cheshire Cat Tail', 500, 7.01),
	('Cosmic Rays', 'Cheeseburger', 600, 9.95),
	('Donut Box', 'Chocolate Donut', 450, 4.45);
	

/*
TRIGGER FUNCTION 1/2
Calculates the number of visitors to each park
*/
CREATE FUNCTION update_NumVisitors()
	RETURNS TRIGGER
	LANGUAGE plpgsql
	AS $$
	BEGIN
		UPDATE "PARKS"
			SET "NumVisitors" = "NumVisitors" + 1
			WHERE "Name" IN(
				SELECT "Park" FROM "PLACES"
					WHERE "Name" = NEW."FavPlace"
			);
		RETURN NEW;
	END $$;


CREATE TRIGGER update_NumVisitors
	AFTER INSERT ON "VISITORS"
	FOR EACH ROW EXECUTE FUNCTION update_NumVisitors();



-- 'First Timer', 'Season Pass Holder', '>3 Hr Drive', '<5 Hr Drive', 'Out of Country'
INSERT INTO "VISITORS" VALUES
	('Ashley', 'Theimer', 'Wilderness Lodge', 'Haunted Mansion', '<5 Hr Drive'),
	('Jane', 'Doe', NULL, 'Flight of Passage', '>3 Hr Drive'),
	('Lauren', 'Tekely', NULL, 'Space Mountain', '<5 Hr Drive'),
	('Megan', 'Joyce', 'Grand Floridian', 'Rockin Roller Coaster', '<5 Hr Drive'), 
	('Aniyah', 'Dixon', NULL, 'Peter Pans Flight', 'First Timer'),
	('Marley', 'Leach', NULL, 'Pirates of the Caribbean', 'First Timer'),
	('Alyssa', 'Theimer', 'Wilderness Lodge', 'Living With the Land', '<5 Hr Drive'),
	('John', 'Doe', 'Contemporary', 'Tower of Terror', 'Out of Country'),
	('John', 'Wilson', 'Contemporary', 'Sorin', 'Season Pass Holder'),
	('Jimmy', 'Theimer', 'Wilderness Lodge', 'Haunted Mansion', '<5 Hr Drive');
	


INSERT INTO "TRANSACTIONS" VALUES
	('Ashley', 'Theimer', 'Mickey Emporium', 'T-shirt', DEFAULT, 12.00),
	('Ashley', 'Theimer', 'Mickey Emporium', 'Backpack', DEFAULT, 55.00),
	('Aniyah', 'Dixon', 'Mickey Emporium', 'Stuffed Animal', DEFAULT, 20.00),
	('Alyssa', 'Theimer', 'Epcot Shop', 'Backpack', DEFAULT, 50.00),
	('John', 'Wilson', 'Epcot Shop', 'Fli[ Flops', DEFAULT, 15.00),
	('Marley', 'Leach', 'Disneyland Shop', 'T-shirt', DEFAULT, 13.00),
	('Jimmy', 'Theimer', 'Tower of Terror', 'Mickey Ears', DEFAULT, 45.00),
	('Ashley', 'Theimer', 'Haunted Mansion', 'Playing cards', DEFAULT, 30.00),
	('Jane', 'Doe', 'Pandora Store', 'Banshee', DEFAULT, 60.34);



/*
1/10
OUTER JOIN use 1/3
JOIN Use 1/5
Has a WHERE clause with user controled variable 1/5
Shows the transactions made at each Place
*/
CREATE FUNCTION transactions_by_location(MoneyMinimum MONEY)
	RETURNS TABLE(
		"Location"		TEXT,
		"Park Location"	"parks",
		"Total Spent"	MONEY
	)
	LANGUAGE plpgsql
	AS $$
	BEGIN
		RETURN QUERY SELECT "PLACES"."Name", "PLACES"."Park", "TRANSACTIONS"."Total" 
			FROM "PLACES"
			LEFT OUTER JOIN "TRANSACTIONS" ON "TRANSACTIONS"."Place" = "PLACES"."Name"
			WHERE "Total" > MoneyMinimum;
	END$$;



/*
2/10
New Keyword EXCEPT 
Shows the VISITORS that are not EMPLOYEES
*/
CREATE FUNCTION visitors_not_employees()
	RETURNS TABLE(
		"First Name"	TEXT,
		"Last Name"		TEXT
	)
	LANGUAGE plpgsql
	AS $$
	BEGIN
		RETURN QUERY SELECT "Fn", "Ln" FROM "VISITORS"
			EXCEPT
			SELECT "Fn", "Ln" FROM "EMPLOYEES";
	END$$;

/*
3/10
New Keywords OVER, PARTITION, ROW_NUMBER()
sorts groups places together and sorts its employees by althebetical order and gives them an althebetical rank
*/
CREATE FUNCTION sorted_employee_by_location()
	RETURNS TABLE(
		"Location"	TEXT,
		"First Name"	TEXT,
		"Last Name"		TEXT,
		"Work Email"	TEXT,
		"Phone Number"	VARCHAR(22),
		"Employee Number" BIGINT
	)
	LANGUAGE plpgsql
	AS $$
	BEGIN
		RETURN QUERY SELECT "Place", "Fn","Ln", "Email", "PhoneNum",
			ROW_NUMBER() OVER(PARTITION BY "Place" ORDER BY "Ln", "Fn" ASC) AS "Row Number"
			FROM "EMPLOYEES";
	END$$;
	
/*
4/10
Aggregate Function 1/3 
uses a GROUP BY 1/1
shows the number of transactions made at a place and the total earnings of that location
*/
CREATE FUNCTION show_trans_total_at_location()
	RETURNS TABLE(
		"Location"			TEXT,
		"Num Transactions"	BIGINT,
		"Total Revenue"		MONEY
	)
	LANGUAGE plpgsql
	AS $$
	BEGIN
		RETURN QUERY SELECT "Place", COUNT("Place"), SUM("Total"::NUMERIC)::MONEY FROM "TRANSACTIONS"
			GROUP BY "Place";
	END$$;


/*
5/10
JOIN use 2/5 
JOINS 3 Tables together 1/2
Shows the employees that only work for rides
*/
CREATE FUNCTION show_all_ride_workers()
	RETURNS TABLE(
		"Ride"			TEXT,
		"First Name"	TEXT,
		"Last Name"		TEXT
	)
	LANGUAGE plpgsql
	AS $$
	BEGIN
		RETURN QUERY SELECT "RIDES"."Name", "EMPLOYEES"."Fn", "EMPLOYEES"."Ln" 
			FROM "EMPLOYEES"
			INNER JOIN "PLACES" ON "EMPLOYEES"."Place" = "PLACES"."Name"
			INNER JOIN "RIDES" ON "PLACES"."Name" = "RIDES"."Name"
			ORDER BY "RIDES"."Name" ASC;
	END$$;
	


/*
6/10
JOIN use 3/5
JOINS 3 Tables together 2/2
Has a WHERE clause with user controled variable 2/5
Shows the employees that only work for a specific ride
*/
CREATE FUNCTION show_specific_ride_workers(SearchedRide TEXT)
	RETURNS TABLE(
		"Ride"			TEXT,
		"First Name"	TEXT,
		"Last Name"		TEXT
	)
	LANGUAGE plpgsql
	AS $$
	BEGIN
		RETURN QUERY SELECT "RIDES"."Name", "EMPLOYEES"."Fn", "EMPLOYEES"."Ln" 
			FROM "EMPLOYEES"
			INNER JOIN "PLACES" ON "EMPLOYEES"."Place" = "PLACES"."Name"
			INNER JOIN "RIDES" ON "PLACES"."Name" = "RIDES"."Name"
			WHERE "RIDES"."Name" = SearchedRide
			ORDER BY "RIDES"."Name" ASC;
	END$$;


/*
7/10
OUTER JOIN Use 2/3
JOIN use 4/5
JOINS 3 Tables together 3/2
Shows the thrill less rides, the ride type, their theme, their park, and their park ticket price
This data will help families decide which park to go to
*/
CREATE FUNCTION show_non_thrill_rides()
	RETURNS TABLE(
		"Non-Thrill Rides"	TEXT,
		"Style"				"Ride_Types",
		"Story"				TEXT,
		"Which Park"		"parks",
		"Park Ticket Price"	MONEY
	)
	LANGUAGE plpgsql
	AS $$
	BEGIN
		RETURN QUERY SELECT "RIDES"."Name" AS "Non-Thrill Rides", "RIDES"."Type", 
			"PLACES"."Theme", "PLACES"."Park", 
			"PARKS"."TicketPrice"
			FROM "RIDES"
			RIGHT OUTER JOIN "PLACES" ON "PLACES"."Name" = "RIDES"."Name"
			RIGHT OUTER JOIN "PARKS" ON "PLACES"."Park" = "PARKS"."Name"
			WHERE "Type" != 'Thrill' OR "Type" != 'Roller Coaster'
			ORDER BY "PLACES"."Park" ASC;
	END$$;

/*
8/10
OUTER JOIN Use 3/3
JOIN use 5/5
JOINS 3 Tables together 3/2
Has a WHERE clause with user controled variable 3/5
allows user to search for a specific type of ride
*/
CREATE FUNCTION search_for_type_rides(RideSearch "Ride_Types")
	RETURNS TABLE(
		"Ride Name"	TEXT,
		"Style"				"Ride_Types",
		"Story"				TEXT,
		"Which Park"		"parks",
		"Park Ticket Price"	MONEY
	)
	LANGUAGE plpgsql
	AS $$
	BEGIN
		RETURN QUERY SELECT "RIDES"."Name" AS "Non-Thrill Rides", "RIDES"."Type", 
			"PLACES"."Theme", "PLACES"."Park", 
			"PARKS"."TicketPrice"
			FROM "RIDES"
			RIGHT OUTER JOIN "PLACES" ON "PLACES"."Name" = "RIDES"."Name"
			RIGHT OUTER JOIN "PARKS" ON "PLACES"."Park" = "PARKS"."Name"
			WHERE "Type" = RideSearch
			ORDER BY "PLACES"."Park" ASC;
	END$$;


/*
9/10
User-Controled Variable Function
calculates money based on park ticket and transactions
*/
CREATE FUNCTION calculate_revenue(numVisit INTEGER, ticketCost MONEY, transSum NUMERIC)
	RETURNS MONEY
	LANGUAGE plpgsql
	AS $$
	DECLARE
		ticketRev NUMERIC = (numVisit::NUMERIC * ticketCost::NUMERIC);
		transRev NUMERIC = transSum;
		revenue MONEY = (ticketRev + transRev)::MONEY;
	BEGIN
		RETURN revenue;
	END $$;

/*
10/10
JOIN use 6/5
JOINS 3 Tables together 4/2
shows calculated revenue for each park
*/
CREATE FUNCTION show_parks_calculated_revenue()
	RETURNS TABLE(
			"Park"		"parks",
			"Revenue"	MONEY
	)
	LANGUAGE plpgsql
	AS $$
	BEGIN
		RETURN QUERY SELECT "PARKS"."Name", calculate_revenue("PARKS"."NumVisitors", "PARKS"."TicketPrice", SUM("TRANSACTIONS"."Total"::NUMERIC)) AS "MoneyCollected"
			FROM "PARKS"
			RIGHT OUTER JOIN "PLACES" ON "PLACES"."Park" = "PARKS"."Name"
			FULL OUTER JOIN "TRANSACTIONS" ON "PLACES"."Name" = "TRANSACTIONS"."Place"
			GROUP BY "PARKS"."Name";
	END $$;
	

/*
11/10
JOIN use 7/5
JOINS 3 Tables together 5/2
shows individual visitors money spent
*/
CREATE FUNCTION show_individual_visitors_money_spent()
	RETURNS TABLE(
			"Fn"		TEXT,
			"Ln"		TEXT,
			"VisitorType"		"visitor_type",
			"Park"		"parks",
			"MoneySpent"	MONEY
	)
	LANGUAGE plpgsql
	AS $$
	BEGIN
		RETURN QUERY SELECT "TRANSACTIONS"."Fn", "TRANSACTIONS"."Ln", "VISITORS"."VisitorType", "PARKS"."Name", calculate_revenue(1, "PARKS"."TicketPrice", SUM("TRANSACTIONS"."Total"::NUMERIC))
			FROM "VISITORS"
			INNER JOIN "TRANSACTIONS" ON ("TRANSACTIONS"."Fn", "TRANSACTIONS"."Ln") = ("VISITORS"."Fn", "VISITORS"."Ln")
			INNER JOIN "PLACES" ON "TRANSACTIONS"."Place" = "PLACES"."Name"
			INNER JOIN "PARKS" ON "PLACES"."Park" = "PARKS"."Name"
			GROUP BY "VISITORS"."VisitorType", ("TRANSACTIONS"."Fn", "TRANSACTIONS"."Ln"), "PARKS"."Name"
			ORDER BY "VISITORS"."VisitorType", ("TRANSACTIONS"."Fn", "TRANSACTIONS"."Ln");
	END $$;



/*
12/10
Has a WHERE clause with user controled variable 4/5
New Keywords CONCAT and LEFT
Shows the employees initials and salaries
*/
CREATE FUNCTION show_employees_salaries_and_initials(SalaryMin MONEY)
	RETURNS TABLE(
		"First Name"	TEXT,
		"Last Name"		TEXT,
		"Initials"		TEXT,
		"Salary"		MONEY
	)
	LANGUAGE plpgsql
	AS $$
	BEGIN
		RETURN QUERY SELECT "EMPLOYEES"."Fn", "EMPLOYEES"."Ln", CONCAT(LEFT("EMPLOYEES"."Fn", 1), LEFT("EMPLOYEES"."Ln", 1)), "POSITIONS"."Salary"
			FROM "EMPLOYEES"
			INNER JOIN "POSITIONS" ON "EMPLOYEES"."PosName" = "POSITIONS"."PosName"
			WHERE "POSITIONS"."Salary" > SalaryMin
			ORDER BY "POSITIONS"."Salary" DESC;
	END$$;


/*
13/10
Has a WHERE clause with user controled variable 5/5
Shows the all snacks with calories lower than a given number
*/
CREATE FUNCTION show_snacks_with_calories_lower_than(cal INTEGER)
	RETURNS TABLE(
		"Location"			TEXT,
		"Snack"			TEXT,
		"Calories Count"		INTEGER,
		"Price"			MONEY
	)
	LANGUAGE plpgsql
	AS $$
	BEGIN
		RETURN QUERY SELECT *
			FROM "SNACKS"
			WHERE "SNACKS"."Calories" < cal
			ORDER BY "SNACKS"."Calories" DESC;
	END$$;




/*
TRIGGER FUNCTION 1/2
Adds another collumn to the TRANSPORTATION table for the new park
*/
CREATE FUNCTION update_Transportation()
	RETURNS TRIGGER
	LANGUAGE plpgsql
	AS $$
	BEGIN
		UPDATE  "TRANSPORTATION"
			SET "MK" = FALSE
			WHERE "Type" = NEW."Type";
		UPDATE  "TRANSPORTATION"
			SET "DL"= FALSE
			WHERE "Type" = NEW."Type";
		UPDATE  "TRANSPORTATION"
			SET "HS"= FALSE
			WHERE "Type" = NEW."Type";
		UPDATE  "TRANSPORTATION"			
			SET"Epcot" = FALSE
			WHERE "Type" = NEW."Type";
		UPDATE  "TRANSPORTATION"
			SET "AK" = FALSE
			WHERE "Type" = NEW."Type";
		UPDATE  "TRANSPORTATION"
			SET "NumHotels" = 0
			WHERE "Type" = NEW."Type";
		RETURN NEW;
	END $$;


CREATE TRIGGER signal_Transportation
	AFTER INSERT ON "TRANSPORTATION"
	FOR EACH ROW EXECUTE FUNCTION update_Transportation();



/* SELECT * FROM "PARKS";
SELECT * FROM transactions_by_location('$15');
SELECT * FROM visitors_not_employees();
SELECT * FROM sorted_employee_by_location();
SELECT * FROM show_trans_total_at_location();
SELECT * FROM show_all_ride_workers();
SELECT * FROM show_specific_ride_workers('Haunted Mansion');
SELECT * FROM show_non_thrill_rides();
SELECT * FROM search_for_type_rides('Thrill');
SELECT * FROM show_parks_calculated_revenue();
SELECT * FROM show_individual_visitors_money_spent();
SELECT * FROM show_employees_salaries_and_initials('$15');
SELECT * FROM show_snacks_with_calories_lower_than(500);
INSERT INTO "TRANSPORTATION" VALUES
	('Taxi', TRUE, TRUE, TRUE, TRUE, TRUE, 70, 25);
SELECT * FROM "TRANSPORTATION"; */
